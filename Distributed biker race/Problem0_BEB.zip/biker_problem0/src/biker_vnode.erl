-module(biker_vnode).
-behaviour(riak_core_vnode).
-include("biker.hrl").

-export([start_vnode/1,
         init/1,
         terminate/2,
         handle_command/3,
         is_empty/1,
         delete/1,
         handle_handoff_command/3,
         handoff_starting/2,
         handoff_cancelled/1,
         handoff_finished/2,
         handle_handoff_data/2,
         encode_handoff_item/2,
         handle_coverage/4,
         handle_exit/3]).

-record(state, {partition, s}).

%% API
start_vnode(I) ->
    riak_core_vnode_master:get_vnode_pid(I, ?MODULE).

init([Partition]) ->
	% initialize the vnode state
	S = [{dist_end, 100}, 
         {energy, 112}, 
         {position, 0}, 
         {speed, 0}, 
         {round, 10}, 
         {follow, none}, 
         {handleFollow, false}, 
         {boost, false}, 
         {crashed, false},
         {roundNumber, 0}],
    {ok, #state{partition=Partition, s=S}}.

%% Sample command: respond to a ping
handle_command(ping, _Sender, State) ->
    {reply, {pong, State#state.partition}, State};

% update the state of the vnode according to the broadcasted speed 
% S: broadcasted speed.
% Node: id of the node sending the commande.
handle_command({broadcast_speed, S, Node}, _Sender, #state{s=CurrentState}=State) ->
    N = node(),
    case Node of 
        N ->
            % update state of the vnode
            NewState = update_speed(CurrentState, S),
            NewState2 = update_position(NewState, S),
            NewState3 = update_energy(NewState2, S),
            NewState4 = update_roundNumber(NewState3, 1),
            NewState5 = update_follow(NewState4, none),
            NewState6 = update_handleFollow(NewState5, false),
            {reply, {N, NewState6}, State#state{s=NewState6}};
        _ -> 
            {reply, no_change, State}
    end;

% update the state of the vnode (after the boost)
% Node: id of the node sending the commande.
handle_command({broadcast_boost, Node}, _Sender, #state{s=CurrentState}=State) ->
    N = node(),
    case Node of 
        N ->
            % update state of the vnode
            NewState = update_speed_boost(CurrentState),
            [{_, S}] = [{Key, Val} || {Key, Val} <- NewState, Key =:= speed],
            NewState2 = update_position(NewState, S),
            NewState3 = update_energy_boost(NewState2),
            NewState4 = update_roundNumber(NewState3, 1),
            NewState5 = update_follow(NewState4, none),
            NewState6 = update_handleFollow(NewState5, false),
            {reply, {N, NewState6}, State#state{s=NewState6}};
        _ -> 
            {reply, no_change, State}
    end;


% update the state of the vnode (assign the follow field with BikerId and set handleFollow to true)
% BikerId: Id of the followed biker
% Node: id of the node sending the commande.
handle_command({broadcast_follow, BikerId, Node}, _Sender, #state{s=CurrentState}=State) ->
    N = node(),
    case Node of 
        N ->
            % update state of the vnode
            NewState = update_follow(CurrentState, BikerId),
            NewState2 = update_handleFollow(NewState, true),
            NewState3 = update_roundNumber(NewState2, 1),
            {reply, {N, NewState3}, State#state{s=NewState3}};
        _ -> 
            {reply, no_change, State}
    end;

% update the state of the vnodes corresponding to a biker following another biker
handle_command({edit_state, S}, _Sender, #state{s=CurrentState}=State) ->
    [{_, NewSpeed}] = [{Key, Val} || {Key, Val} <- S, Key =:= speed],
    [{_, NewPosition}] = [{Key, Val} || {Key, Val} <- S, Key =:= position],
    [{_, NewEnergy}] = [{Key, Val} || {Key, Val} <- S, Key =:= energy],
    NewState1 = lists:sublist(CurrentState,1) ++ [{energy, NewEnergy}] ++ lists:nthtail(2,CurrentState),
    NewState2 = lists:sublist(NewState1,2) ++ [{position, NewPosition}] ++ lists:nthtail(3,NewState1),
    NewState3 = lists:sublist(NewState2,3) ++ [{speed, NewSpeed}] ++ lists:nthtail(4,NewState2),
    {reply, {node(), NewState3}, State#state{s=NewState3}};

% update the state of the vnodes corresponding to a biker following another biker
handle_command({apply_follow_updates, Speed, Position}, _Sender, #state{s=CurrentState}=State) ->
    NewState1 = update_speed(CurrentState, Speed),
    NewState2 = update_position_after_follow(NewState1, Position),
    NewState3 = update_energy_after_follow(NewState2, Speed),
    NewState4 = update_follow(NewState3, none),
    NewState5 = update_handleFollow(NewState4, false),
    {reply, {node(), NewState5}, State#state{s=NewState5}};

% return the state of the vnode
handle_command(get_state, _Sender, State) ->
    N = node(),
    {reply, {N, State#state.s}, State};

handle_command(Message, _Sender, State) ->
    ?PRINT({unhandled_command, Message}),
    {noreply, State}.

handle_handoff_command(_Message, _Sender, State) ->
    {noreply, State}.

handoff_starting(_TargetNode, State) ->
    {true, State}.

handoff_cancelled(State) ->
    {ok, State}.

handoff_finished(_TargetNode, State) ->
    {ok, State}.

handle_handoff_data(_Data, State) ->
    {reply, ok, State}.

encode_handoff_item(_ObjectName, _ObjectValue) ->
    <<>>.

is_empty(State) ->
    {true, State}.

delete(State) ->
    {ok, State}.

handle_coverage(_Req, _KeySpaces, _Sender, State) ->
    {stop, not_implemented, State}.

handle_exit(_Pid, _Reason, State) ->
    {noreply, State}.

terminate(_Reason, _State) ->
    ok.

% update the state of the vnode (biking by myself)
% State: current state
% Input: speed choosen by the user
update_energy(State, Input) ->
    CurrentField = [{Key, Val} || {Key, Val} <- State, Key =:= energy],
    UpdatedField = case CurrentField of
                        [{_K, _V}] ->
                            {_K, erlang:round(_V - (0.12 * Input * Input))}
                    end,
    NewState = lists:sublist(State,1) ++ [UpdatedField] ++ lists:nthtail(2,State),
    NewState.

% update the state of the vnode (after boost)
% State: current state
% Input: speed choosen by the user
update_energy_boost(State) ->
    CurrentField = [{Key, Val} || {Key, Val} <- State, Key =:= energy],
    UpdatedField = case CurrentField of
                        [{_K, _V}] ->
                            {_K, 0}
                    end,
    NewState = lists:sublist(State,1) ++ [UpdatedField] ++ lists:nthtail(2,State),
    NewState.

% update the state of the vnode 
% State: current state
% Input: speed of the followed biker
update_energy_after_follow(State, Input) ->
    CurrentField = [{Key, Val} || {Key, Val} <- State, Key =:= energy],
    UpdatedField = case CurrentField of
                        [{_K, _V}] ->
                            {_K, erlang:round(_V - (0.06 * Input * Input))}
                    end,
    NewState = lists:sublist(State,1) ++ [UpdatedField] ++ lists:nthtail(2,State),
    NewState.

% update the state of the vnode
% State: current state
% Input: speed choosen by the user
update_position(State, Input) ->
    CurrentField = [{Key, Val} || {Key, Val} <- State, Key =:= position],
    UpdatedField = case CurrentField of
                        [{_K, _V}] ->
                            {_K, _V + Input}
                    end,
    NewState = lists:sublist(State,2) ++ [UpdatedField] ++ lists:nthtail(3,State),
    NewState.

% update the state of the vnode
% State: current state
% Input: new position (same position as followed biker)
update_position_after_follow(State, Input) ->
    CurrentField = [{Key, Val} || {Key, Val} <- State, Key =:= position],
    UpdatedField = case CurrentField of
                        [{_K, _V}] ->
                            {_K, Input}
                    end,
    NewState = lists:sublist(State,2) ++ [UpdatedField] ++ lists:nthtail(3,State),
    NewState.

% update the state of the vnode
% State: current state
% Input: new value for the speed
update_speed(State, Input) ->
    CurrentField = [{Key, Val} || {Key, Val} <- State, Key =:= speed],
    UpdatedField = case CurrentField of
                        [{_K, _V}] ->
                            {_K, Input}
                    end,
    NewState = lists:sublist(State,3) ++ [UpdatedField] ++ lists:nthtail(4,State),
    NewState.

% update the state of the vnode
% State: current state
% Input: new value for the speed
update_speed_boost(State) ->
    CurrentField = [{Key, Val} || {Key, Val} <- State, Key =:= speed],
    UpdatedField = case CurrentField of
                        [{_K, _V}] ->
                            % get remaining energy
                            [{_, E}] =  [{Key, Val} || {Key, Val} <- State, Key =:= energy],
                            {_K, erlang:round(3.87 * math:sqrt(E))}
                    end,
    NewState = lists:sublist(State,3) ++ [UpdatedField] ++ lists:nthtail(4,State),
    NewState.

% update the state of the vnode
% State: current state
% BikerId: id of the followed biker 
update_follow(State, BikerId) ->
    CurrentField = [{Key, Val} || {Key, Val} <- State, Key =:= follow],
    UpdatedField = case CurrentField of
                        [{_K, _V}] ->
                            {_K, BikerId}
                    end,
    NewState = lists:sublist(State,5) ++ [UpdatedField] ++ lists:nthtail(6,State),
    NewState.

% update the state of the vnode (assign the value of Input to handleFollow's field)
% State: current state
% Input : true/false
update_handleFollow(State, Input) ->
    CurrentField = [{Key, Val} || {Key, Val} <- State, Key =:= handleFollow],
    UpdatedField = case CurrentField of
                        [{_K, _V}] ->
                            {_K, Input}
                    end,
    NewState = lists:sublist(State,6) ++ [UpdatedField] ++ lists:nthtail(7,State),
    NewState.

% update the state of the vnode (increment the round number)
% State: current state
% Input : 1
update_roundNumber(State, Input) ->
    CurrentField = [{Key, Val} || {Key, Val} <- State, Key =:= roundNumber],
    UpdatedField = case CurrentField of
                        [{_K, _V}] ->
                            {_K, (_V + Input)}
                    end,
    NewState = lists:sublist(State,9) ++ [UpdatedField],
    NewState.
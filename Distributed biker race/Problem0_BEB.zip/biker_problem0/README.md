# Skeleton for biker race application (LSINF2345 Project)

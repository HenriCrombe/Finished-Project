package Task_1_1;
import java.io.Serializable;


public class Message implements Serializable {
	
	/**
	 * The Message class is used to represent the messages that are exchanged between the client and the server 
	 */

	private static final long serialVersionUID = 1L;
	int id; // ID of the message
	Matrix result; // the resulting matrix 
	Matrix matrix; // the matrix to compute
	int exponent; 
	long sending_time; // Request sending time
	long arrival_time; // Request arrival time
	long execution_time; // The execution time in ms (computed on the server)
	long response_time; // Request response time 
	long time_on_network; // Time the request spent in the network (buffer time included)
	

	public Message(int id,Matrix m, int e){
		this.id = id;
		this.matrix = m;
		this.exponent = e;
		this.result = null;
		this.sending_time = 0;
		this.arrival_time = 0;
		this.execution_time = 0;
		this.response_time = 0;
		this.time_on_network = 0;
	}

	public Matrix getResult() {
		return result;
	}

	public void setResult(Matrix result) {
		this.result = result;
	}

	public Matrix getMatrix() {
		return matrix;
	}

	public void setMatrix(Matrix matrix) {
		this.matrix = matrix;
	}

	public int getExponent() {
		return exponent;
	}

	public void setExponent(int exponent) {
		this.exponent = exponent;
	}

	public long getSending_time() {
		return sending_time;
	}

	public void setSending_time(long sending_time) {
		this.sending_time = sending_time;
	}

	public long getArrival_time() {
		return arrival_time;
	}

	public void setArrival_time(long arrival_time) {
		this.arrival_time = arrival_time;
	}

	public long getExecution_time() {
		return execution_time;
	}

	public void setExecution_time(long execution_time) {
		this.execution_time = execution_time;
	}
}

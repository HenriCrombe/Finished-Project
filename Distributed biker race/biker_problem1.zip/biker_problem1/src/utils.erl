-module(utils).

-export([player_input/1,
		 start_receiver/0]).

player_input(State) ->
	% verify that the energy is higher than 0 !!

	{_Val1, _Val2, List} = State,
	RemainingEnergy= [{Key, Val} || {Key, Val} <- List, Key =:= energy, Val > 0],

	case RemainingEnergy of 
		[{_,_}] -> io:format("If you want to:~n"),
				   io:format(" -Entrer a new speed, write: speed(X)~n"),
				   io:format(" -Follow a player, write: follow(X)~n"),
				   io:format(" -Use the boost, write: boost()~n~n");

				   % Bug !!
				   % Line = io:get_line("Your choice: "),
				   % io:format("~n~nYour choice was: ~w",[Line]);

		[] -> io:format("You have no energy to continue...")
	end.

start_receiver() ->
	receive
		{From, message} ->
			io:format("Message bien reçu~n"),
			From ! ack,
			start_receiver();
		ack ->
			io:format("Fin de communication !"),
			ok
	end.

	
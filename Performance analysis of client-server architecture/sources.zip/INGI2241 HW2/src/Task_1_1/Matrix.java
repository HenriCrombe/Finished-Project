package Task_1_1;
import java.io.Serializable;

public class Matrix implements Serializable {
	
	/**
	 * The Matrix class represents matrix of size l x c
	 * Matrix values are stores in a two dimensional array of doubles
	 */
	
	private static final long serialVersionUID = 1L;
	double [][] m;
	int l;
	int c;
	
	/**
	 * Create a matrix of size l x c with random double values.
	 */
	public Matrix(int l, int c){
		this.m = new double[l][c];
		this.l = l;
		this.c = c;
		for(int i=0;i<l;i++){
			for(int j=0;j<c;j++){
				m[i][j] = (long)(Math.random()); 
			}
		}
	} 
	
	/**
	 * Multiply the current matrix to itself and return the response in a new Matrix
	 * @return the computation of MxM 
	 */
    public Matrix multiply(){
    	Matrix result = new	Matrix(this.getLineLgth(),this.getColonLgth());
    	for(int i=0;i<l;i++){
			for(int j=0;j<c;j++){
				for (int k = 0; k < c; k++) { 
                    result.m[i][j] += m[i][k] * m[k][j];
                }	
			}		
    	}
    	return result;
    }
    /**
     * Compute M^p
     * @return
     */
    public Matrix exponent(int p){
    	Matrix result = multiply();
    	for(int i = 2; i < p ; i++){
    		result = multiply();
    	}
    	return result;	
    }
    
	public void print(){
		for(int i=0;i<l;i++){
			for(int j=0;j<c;j++){
				System.out.print(m[i][j]+" ");	
			}
			System.out.println();
		}
	}
	
	public int getColonLgth(){
		return this.c;
	}
	
	public int getLineLgth(){
		return this.c;
	}
	
}

package Task_2_1;
import java.net.*;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;


public class ServerMultiThread {
	/**
	 * This Server class is our implementation of the multi-threaded server.
	 * The server uses a pool ExecutorService to handle threads synchronization. 
	 * Upon arrival of a new client and if a thread is available,
	 * a new thread ServerHandler is started in order to handle the request
	 */
	
	public static void main(String[] args) {
		
		int nmb_threads = 16;
		final ExecutorService pool = Executors.newFixedThreadPool(nmb_threads);
			
		try {
			System.out.println("MultiThreaded Server started! ");
			int port = 4444;
			ServerSocket ss = new ServerSocket(port,4444);
			System.out.println("Waiting for messages ");
			for(;;){
				pool.execute(new ServerHandler(ss.accept()));
			}
		} catch(Exception e){System.out.println(e);}
	}
}

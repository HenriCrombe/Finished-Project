package Task_1_1;
import java.net.*;
import java.io.*;

public class Client {
	
	/**
	 * The Client class (of package 1_1) is used to generate data for measurement #1.
	 * 
	 * For measurement #1 :
	 * The client sends requests of varying difficulty to the server. 
	 * The goal of the client is to compute the response time of the server for a given difficulty
	 * The difficulty varies in function of p which is the exponent applied to a given matrix of fixed size.
	 * Only one request is sent at a time in order to get consistent results for the response time.
	 * The client works as follow :
	 * For each difficulty (p varies between [100;2000]), the client send 1000 request with p fixed and
	 * compute the mean response time, the mean network time and the mean execution time.
	 * The results are stored in a log file
	 */
	public static void main(String[] args) throws UnknownHostException, IOException, ClassNotFoundException {

		System.out.println("Client Task 1.1 : Start Measurements #1");
	
		// Test parameters
		int nmb_message = 1000; // nmb of request to send to the server for a given difficulty.
		int matrix_size = 50; // Size of the Matrix to send.
		int p = 100; // Start with exponent p = 100 
		int p_max = 2000; // Maximum exponent to test
		
		// Mean values to compute
		long mean_response_time;
		long mean_exec_time;
		long mean_time_on_network;
		
		// Initialize log file
		String log_filename = "task_1_1_"+matrix_size+"_p_"+p+"_"+p_max;
		BufferedWriter log = init_log(log_filename);
	
		
		for(;p<=p_max;p=p+100){
			mean_response_time = 0;
			mean_exec_time = 0;
			mean_time_on_network = 0;
			for(int i=0; i<nmb_message; i++){
			
				// Create new square Matrix with random values
				Matrix m = new  Matrix(matrix_size,matrix_size);
				
				// Initialize a new serializable Message
				Message message = new Message(i, m, p);
				
				// Create a socket and connect to the server
				// If the server is offline or if the SocketServer queue is full, an exception is thrown
				message.sending_time = System.nanoTime(); 
				Socket s = new Socket ("stuycklvpn.noip.me", 4444);
				//Socket s = new Socket ("localhost", 4444);
				
				// Create an input and output stream to send Messages to the server
				ObjectOutputStream clientOut= new ObjectOutputStream(s.getOutputStream());
		        ObjectInputStream clientIn= new ObjectInputStream(s.getInputStream());

		        // Blocking call to writeObject. 
		        // The message is sent when the server open its input stream.
				clientOut.writeObject(message);

				
				// Blocking call to readObject
				// The client waits until the server responds to the current request (Message).
				Message r = (Message) clientIn.readObject();
				
				// Compute the response time of the current request.
				r.arrival_time = System.nanoTime();
				r.response_time = (r.arrival_time - r.sending_time)/ 1000000;
				
				// Compute the time the resquest spent on the network
				r.time_on_network = r.response_time - r.execution_time;
				
				// Update mean values
				mean_response_time += r.response_time ;
				mean_exec_time += r.execution_time;
				mean_time_on_network += r.time_on_network;
				
				// Log the message and its corresponding timers.
				log_message(log, r);
				
				// Close the socket and the streams
	            clientIn.close();
	    		clientOut.close();
	            s.close();
		        
			}
		
			// Compute the mean values for the current difficulty (p)
			mean_exec_time = mean_exec_time /nmb_message;
			mean_response_time = mean_response_time /nmb_message;
			mean_time_on_network = mean_time_on_network / nmb_message;
			
			// Log the mean values into the log file
			log.write("Mean values for size: "+matrix_size+" with p="+p+" "
					+ "\n Mean rtt: "+mean_response_time 
					+ "\n Mean exec time: "+mean_exec_time
					+" \n Mean time on network: "+mean_time_on_network+"\n");
		}

		// Measurements #1 finished
		log.close();
        System.out.println("Client finished !");
        System.out.println("Logs are stored in : "+log_filename);
					
	} // End of main()
	
	public static void log_message(BufferedWriter log, Message m) throws IOException{
		log.write("Message "+m.id+" :\n");
		log.write("Matrix size : "+m.matrix.c+" | Exponent : "+m.exponent+" | Response Time : "+m.response_time+" ms | Execution time : "+m.execution_time+" ms | Network + buffer time : "+m.time_on_network+" \n");
	}
	
	public static 	BufferedWriter init_log(String filename) throws IOException{
		File file = new File(filename);
		if (!file.exists()) {
			file.createNewFile();
		}
		FileWriter fw = new FileWriter(file.getAbsoluteFile());
		return new BufferedWriter(fw);
	}
	
} // End of class Client

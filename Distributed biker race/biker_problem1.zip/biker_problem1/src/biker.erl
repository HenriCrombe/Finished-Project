-module(biker).
-include("biker.hrl").
-include_lib("riak_core/include/riak_core_vnode.hrl").

-export([
         ping/0,
         start_race/0
        ]).

-record(bikers, {biker1, biker2, biker3, biker4, biker5}).

%% Public API

%% @doc Pings a random vnode to make sure communication is functional
ping() ->
    DocIdx = riak_core_util:chash_key({<<"ping">>, term_to_binary(now())}),
    PrefList = riak_core_apl:get_primary_apl(DocIdx, 1, biker),
    [{IndexNode, _Type}] = PrefList,
    riak_core_vnode_master:sync_spawn_command(IndexNode, ping, biker_vnode_master).

% @doc Starts the race for a given biker.
start_race() ->
	io:format("~n~n######################################################################~n"),
    % get the state of each biker
    Rec = get_bikers_record(),
    % check for a winner
    winner(Rec),
    % based on the round number, I know who is the leader
    % get the round number of a correct biker (not crashed)
    Round = get_current_round(Rec),
    case Round of 
    	1 ->
    		% biker1 is the leader (send user's input to him)
    		display_bikers(Rec),
    		Leader = 'biker1@127.0.0.1',
    		user_input(Leader, Rec, Round); 
    	2 ->
    		% biker2 is the leader (send user's input to him)
    		display_bikers(Rec),
    		Leader = 'biker2@127.0.0.1',
    		user_input(Leader, Rec, Round);
    	3 ->
    		% biker3 is the leader (send user's input to him)
    		display_bikers(Rec),
    		Leader = 'biker3@127.0.0.1',
    		user_input(Leader, Rec, Round);
    	4 ->
    		% biker4 is the leader (send user's input to him)
    		display_bikers(Rec),
    		Leader = 'biker4@127.0.0.1',
    		user_input(Leader, Rec, Round);
    	5 ->
    		% biker5 is the leader (send user's input to him)
    		display_bikers(Rec),
    		Leader = 'biker5@127.0.0.1',
    		user_input(Leader, Rec, Round)
    end,
	% wait for all bikers to be ready (i.e. state updated) before starting new round
	wait_for_ready(Leader, 1),
	start_race().
 

%%%===================================================================
%%% Internal Functions
%%%===================================================================

% get all vnodes present in the ring.
get_member_list() ->
    {ok, CHBin} = riak_core_ring_manager:get_chash_bin(),
    chashbin:to_list(CHBin).

% Return the record containing the global state of the system.
get_bikers_record() ->
    Members = get_member_list(),
    {IndexNode, NodeId} = hd(Members),
    {_IdBiker, S} = riak_core_vnode_master:sync_spawn_command({IndexNode,NodeId}, get_state, biker_vnode_master),
    S.  

% Return the record containing the global state of the system.
get_leader_record(Leader) ->
    Members = get_member_list(),
    Vnodes = [{Index, NodeId} || {Index, NodeId} <- Members, NodeId =:= Leader],
    {IndexNode, NodeId} = hd(Vnodes),
    {_IdBiker, S} = riak_core_vnode_master:sync_spawn_command({IndexNode,NodeId}, get_state, biker_vnode_master),
    S.      

% return the current round of the system
% Rec: record containing the global state of the system
get_current_round(Rec) ->
	B1State = Rec#bikers.biker1,
	B2State = Rec#bikers.biker2,
	B3State = Rec#bikers.biker3,
	B4State = Rec#bikers.biker4,
	B5State = Rec#bikers.biker5,

	[{_, B1round}] = [{Key, Val} || {Key, Val} <- B1State, Key =:= roundNumber],
	[{_, B1position}] = [{Key, Val} || {Key, Val} <- B1State, Key =:= position],
	[{_, B1energy}] = [{Key, Val} || {Key, Val} <- B1State, Key =:= energy],
	[{_, B1crashed}] = [{Key, Val} || {Key, Val} <- B1State, Key =:= crashed],

	[{_, B2round}] = [{Key, Val} || {Key, Val} <- B2State, Key =:= roundNumber],
	[{_, B2position}] = [{Key, Val} || {Key, Val} <- B2State, Key =:= position],
	[{_, B2energy}] = [{Key, Val} || {Key, Val} <- B2State, Key =:= energy],
    [{_, B2crashed}] = [{Key, Val} || {Key, Val} <- B2State, Key =:= crashed],

    [{_, B3round}] = [{Key, Val} || {Key, Val} <- B3State, Key =:= roundNumber],
    [{_, B3position}] = [{Key, Val} || {Key, Val} <- B3State, Key =:= position],
	[{_, B3energy}] = [{Key, Val} || {Key, Val} <- B3State, Key =:= energy],
    [{_, B3crashed}] = [{Key, Val} || {Key, Val} <- B3State, Key =:= crashed],

    [{_, B4round}] = [{Key, Val} || {Key, Val} <- B4State, Key =:= roundNumber],
    [{_, B4position}] = [{Key, Val} || {Key, Val} <- B4State, Key =:= position],
	[{_, B4energy}] = [{Key, Val} || {Key, Val} <- B4State, Key =:= energy],
    [{_, B4crashed}] = [{Key, Val} || {Key, Val} <- B4State, Key =:= crashed],

    [{_, B5round}] = [{Key, Val} || {Key, Val} <- B5State, Key =:= roundNumber],
    [{_, B5position}] = [{Key, Val} || {Key, Val} <- B5State, Key =:= position],
	[{_, B5energy}] = [{Key, Val} || {Key, Val} <- B5State, Key =:= energy],
    [{_, B5crashed}] = [{Key, Val} || {Key, Val} <- B5State, Key =:= crashed],

    L = [{B1round, B1position, B1energy, B1crashed},
         {B2round, B2position, B2energy, B2crashed},
         {B3round, B3position, B3energy, B3crashed},
         {B4round, B4position, B4energy, B4crashed},
         {B5round, B5position, B5energy, B5crashed}],

    % remove crashed, already arrived and without energy nodes 
    Filtered = [{R, P, E, C} || {R, P, E, C} <- L, C =:= false andalso E > 0 andalso P < 100],

    % return the round of a correct biker (round are synchronized) 
    {Round, _, _, _} = hd(Filtered),
    Round.

% take an input from the user and send this input to the leader
% Leader: id of the leader (e.g. 'biker1@127.0.0.1')
% Rec: record containing the global state of the system
% Round: Current round
user_input(Leader, Rec, Round) ->
    case node() of 
        'biker1@127.0.0.1' ->
            State = Rec#bikers.biker1;
        'biker2@127.0.0.1' ->
            State = Rec#bikers.biker2;
        'biker3@127.0.0.1' ->
            State = Rec#bikers.biker3;
        'biker4@127.0.0.1' ->
            State = Rec#bikers.biker4;
        'biker5@127.0.0.1' ->
            State = Rec#bikers.biker5
    end,

    % Check if the biker has any remaining energy
    RemainingEnergy = [{Key, Val} || {Key, Val} <- State, Key =:= energy, Val > 0],
    case RemainingEnergy of 
        [{_,_}] -> 

        	% Check if the biker has not finished the race yet.
        	[{_, Position}] = [{Key, Val} || {Key, Val} <- State, Key =:= position],
        	if Position >= 100 ->
	        		io:format("Congratulation, you reached the finish line !"),
	        		timer:sleep(infinity);
        		true ->
        			% biker still in the race
        			% get all biker "followable" by the current node
		            L = all_possible_follow(node(), Rec),

		            io:format("What do you want:~n~n"),
		            io:format(" -Entrer a new speed ? write: {speed, X}.~n~n"),
		            io:format(" -Follow a player ? ~n"),
		            io:format(" -List of correct biker to follow: ~w~n",[L]),
		            io:format(" -Write: {follow, X}.~n~n"),
		            io:format(" -Use the boost ? write: boost.~n~n"),

		            Line = io:read("Your choice: "),
		            % only update the vnodes of the leader
		            Members = get_member_list(),
					Vnodes = [{Index, NodeId} || {Index, NodeId} <- Members, NodeId =:= Leader],
		            case Line of
		                {ok, {speed, S}} ->
		                    % send user's input to leader
		                    send_to_leader(Vnodes, speed, S);
		                {ok, {follow, BikerId}} ->
		                	% send user's input to leader
		                    send_to_leader(Vnodes, follow, BikerId);
		                {ok, boost} ->
		                	% send user's input to leader
		                	send_to_leader(Vnodes, boost, none);
		                _ -> 
		                	% if wrong user's input then use a default speed of 5
		                	send_to_leader(Vnodes, speed, 5)
		            end,
		            if node() =:= Leader ->
		            		% wait the input of all others bikers
		            		NewState = wait_input_others_bikers(Round, Leader),
		            		% broadcast the new state of the system to all others biker
		            		beb(Members, NewState);
		            	true->
		            		% others bikers wait for the leader to update its state before continuing
		            		wait_input_others_bikers(Round, Leader)
		            end
        	end;
        [] -> 
            io:format("You have no energy to continue..."),
            timer:sleep(infinity)
    end.

% send user's input to the leader in order to update the system's state
send_to_leader([{Partition,Node}|Rest], Mode, Input) ->
    case Mode of 
        speed ->
            _Result = riak_core_vnode_master:sync_spawn_command({Partition,Node},
                                     {send_speed, Input, node()},
                                     biker_vnode_master),

            case Rest of 
                [] ->
                    sending_finished;
                _ ->
                    send_to_leader(Rest, Mode, Input)
            end;
        follow ->
            _Result = riak_core_vnode_master:sync_spawn_command({Partition,Node},
                                     {send_follow, Input, node()},
                                     biker_vnode_master),

            case Rest of 
                [] ->
                    sending_finished;
                _ ->
                    send_to_leader(Rest, Mode, Input)
            end;
        boost ->
            _Result = riak_core_vnode_master:sync_spawn_command({Partition,Node},
                                     {send_boost, node()},
                                     biker_vnode_master),

            case Rest of 
                [] ->
                    sending_finished;
                _ ->
                    send_to_leader(Rest, Mode, Input)
            end
    end.

% broadcast the new state of the system to all bikers
beb([{Partition,Node}|Rest], NewState) ->
	_Result = riak_core_vnode_master:sync_spawn_command({Partition,Node},
                                     {broadcast_new_state, NewState},
                                     biker_vnode_master),

    case Rest of 
        [] ->
            beb_finished;
        _ ->
            beb(Rest, NewState)
    end.


% % return a list containing the biker's ids "followable" by Node
% % Node : id of a biker
% % Rec: record containing the state of each biker
all_possible_follow(Node, Rec) ->
    Result = [],
    B1State = Rec#bikers.biker1,
    [{_, B1position}] = [{Key, Val} || {Key, Val} <- B1State, Key =:= position],
    [{_, B1crashed}] = [{Key, Val} || {Key, Val} <- B1State, Key =:= crashed],
    [{_, B1energy}] = [{Key, Val} || {Key, Val} <- B1State, Key =:= energy],
    B2State = Rec#bikers.biker2,
    [{_, B2position}] = [{Key, Val} || {Key, Val} <- B2State, Key =:= position],
    [{_, B2crashed}] = [{Key, Val} || {Key, Val} <- B2State, Key =:= crashed],
    [{_, B2energy}] = [{Key, Val} || {Key, Val} <- B2State, Key =:= energy],
    B3State = Rec#bikers.biker3,
    [{_, B3position}] = [{Key, Val} || {Key, Val} <- B3State, Key =:= position],
    [{_, B3crashed}] = [{Key, Val} || {Key, Val} <- B3State, Key =:= crashed],
    [{_, B3energy}] = [{Key, Val} || {Key, Val} <- B3State, Key =:= energy],
    B4State = Rec#bikers.biker4,
    [{_, B4position}] = [{Key, Val} || {Key, Val} <- B4State, Key =:= position],
    [{_, B4crashed}] = [{Key, Val} || {Key, Val} <- B4State, Key =:= crashed],
    [{_, B4energy}] = [{Key, Val} || {Key, Val} <- B4State, Key =:= energy],
    B5State = Rec#bikers.biker5,
    [{_, B5position}] = [{Key, Val} || {Key, Val} <- B5State, Key =:= position],
    [{_, B5crashed}] = [{Key, Val} || {Key, Val} <- B5State, Key =:= crashed],
    [{_, B5energy}] = [{Key, Val} || {Key, Val} <- B5State, Key =:= energy],
    
    case Node of 
        'biker1@127.0.0.1' -> 
            if (B2position =< B1position) andalso (B2crashed =/= true) andalso (B2position < 100) andalso (B2energy > 0) ->
                R1 = Result ++ [biker2];
                true ->
                    R1 = []
            end,
            if (B3position =< B1position) andalso (B3crashed =/= true) andalso (B3position < 100) andalso (B3energy > 0) ->
                R2 = lists:append(R1, [biker3]);
                true ->
                    R2 = R1
            end,
            if (B4position =< B1position) andalso (B4crashed =/= true) andalso (B4position < 100) andalso (B4energy > 0) ->
                R3 = lists:append(R2, [biker4]);
                true ->
                    R3 = R2
            end,
            if (B5position =< B1position) andalso (B5crashed =/= true) andalso (B5position < 100) andalso (B5energy > 0) ->
                R4 = lists:append(R3, [biker5]);
                true ->
                    R4 = R3
            end,
            R4;
        'biker2@127.0.0.1' -> 
            if (B1position =< B2position) andalso (B1crashed =/= true) andalso (B1position < 100) andalso (B1energy > 0) ->
                R1 = Result ++ [biker1];
                true ->
                    R1 = []
            end,
            if (B3position =< B2position) andalso (B3crashed =/= true) andalso (B3position < 100) andalso (B3energy > 0) ->
                R2 = lists:append(R1, [biker3]);
                true ->
                    R2 = R1
            end,
            if (B4position =< B2position) andalso (B4crashed =/= true) andalso (B4position < 100) andalso (B4energy > 0) ->
                R3 = lists:append(R2, [biker4]);
                true ->
                    R3 = R2
            end,
            if (B5position =< B2position) andalso (B5crashed =/= true) andalso (B5position < 100) andalso (B5energy > 0) ->
                R4 = lists:append(R3, [biker5]);
                true ->
                    R4 = R3
            end,
            R4;
        'biker3@127.0.0.1' -> 
            if (B1position =< B3position) andalso (B1crashed =/= true) andalso (B1position < 100) andalso (B1energy > 0) ->
                R1 = Result ++ [biker1];
                true ->
                    R1 = []
            end,
            if (B2position =< B3position) andalso (B2crashed =/= true) andalso (B2position < 100) andalso (B2energy > 0) ->
                R2 = lists:append(R1, [biker2]);
                true ->
                    R2 = R1
            end,
            if (B4position =< B3position) andalso (B4crashed =/= true) andalso (B4position < 100) andalso (B4energy > 0) ->
                R3 = lists:append(R2, [biker4]);
                true ->
                    R3 = R2
            end,
            if (B5position =< B3position) andalso (B5crashed =/= true) andalso (B5position < 100) andalso (B5energy > 0) ->
                R4 = lists:append(R3, [biker5]);
                true ->
                    R4 = R3
            end,
            R4;
        'biker4@127.0.0.1' -> 
            if (B1position =< B4position) andalso (B1crashed =/= true) andalso (B1position < 100) andalso (B1energy > 0) ->
                R1 = Result ++ [biker1];
                true ->
                    R1 = []
            end,
            if (B2position =< B4position) andalso (B2crashed =/= true) andalso (B2position < 100) andalso (B2energy > 0) ->
                R2 = lists:append(R1, [biker2]);
                true ->
                    R2 = R1
            end,
            if (B3position =< B4position) andalso (B3crashed =/= true) andalso (B3position < 100) andalso (B3energy > 0) ->
                R3 = lists:append(R2, [biker3]);
                true ->
                    R3 = R2
            end,
            if (B5position =< B4position) andalso (B5crashed =/= true) andalso (B5position < 100) andalso (B5energy > 0) ->
                R4 = lists:append(R3, [biker5]);
                true ->
                    R4 = R3
            end,
            R4;
        'biker5@127.0.0.1' -> 
            if (B1position =< B5position) andalso (B1crashed =/= true) andalso (B1position < 100) andalso (B1energy > 0) ->
                R1 = Result ++ [biker1];
                true ->
                    R1 = []
            end,
            if (B2position =< B5position) andalso (B2crashed =/= true) andalso (B2position < 100) andalso (B2energy > 0) ->
                R2 = lists:append(R1, [biker2]);
                true ->
                    R2 = R1
            end,
            if (B3position =< B5position) andalso (B3crashed =/= true) andalso (B3position < 100) andalso (B3energy > 0) ->
                R3 = lists:append(R2, [biker3]);
                true ->
                    R3 = R2
            end,
            if (B4position =< B5position) andalso (B4crashed =/= true) andalso (B4position < 100) andalso (B4energy > 0) ->
                R4 = lists:append(R3, [biker4]);
                true ->
                    R4 = R3
            end,
            R4
    end.	

% Wait for the input of all bikers to be propagated on the state
% Round: current round of the system
wait_input_others_bikers(Round, Leader) ->
	Rec = get_leader_record(Leader),
	% check if the round number = (Round + 1) for all correct bikers
	if (Round + 1) > 5 ->
			RoundToCheck = 1;
		true ->
			RoundToCheck = Round + 1
	end,

	Filtered3 = transform_record_to_list(Rec),

    % check if the round of all remaining bikers = RoundToCheck
    case Filtered3 of 
    	[] ->
    		[];
    	_ ->
		    Res = lists:filter(fun({V1, _, _, _}) -> V1 =:= RoundToCheck end, Filtered3),
		    if Filtered3 == Res ->
		    		% Update the position, speed and energy of bikers following another biker
		    		L = get_bikers_running_by_themselves_info(Rec),
		    		NewRec = update_record_after_follow(Rec, L),
		    		NewRec;
		    	true ->
		    		timer:sleep(1000),
		    		wait_input_others_bikers(Round, Leader)
   		    end
    end.


% Verify if the round number of all correct bikers is the same as the leader
% If not, then at least one correct biker has not updated its state with the state broadcasted by the leader. 
wait_for_ready(Leader, Cpt) ->
	if Cpt == 4 orelse Cpt == 8 ->
		Members = get_member_list(),
		LeaderRec = get_leader_record(Leader),
		beb(Members, LeaderRec),
		wait_for_ready(Leader, Cpt+1);

	true ->
		LeaderRec = get_leader_record(Leader),

		ListLeader = transform_record_to_list(LeaderRec),
		ListLeaderUpdated = [{R, C} || {R, C, _E, _P} <- ListLeader],

		Members = get_member_list(),

		VnodesB1 = [{I1, N1} || {I1, N1} <- Members, N1 =:= 'biker1@127.0.0.1'],
	    {IndexB1, NodeB1} = hd(VnodesB1),
	    {_, StateB1} = riak_core_vnode_master:sync_spawn_command({IndexB1,NodeB1}, get_state, biker_vnode_master),
	    ListB1 = transform_record_to_list(StateB1),
	    ListB1Updated = [{R, C} || {R, C, _E, _P} <- ListB1],

		VnodesB2 = [{I2, N2} || {I2, N2} <- Members, N2 =:= 'biker2@127.0.0.1'],
	    {IndexB2, NodeB2} = hd(VnodesB2),
	    {_, StateB2} = riak_core_vnode_master:sync_spawn_command({IndexB2,NodeB2}, get_state, biker_vnode_master),
	    ListB2 = transform_record_to_list(StateB2),
	    ListB2Updated = [{R, C} || {R, C, _E, _P} <- ListB2],

	    VnodesB3 = [{I3, N3} || {I3, N3} <- Members, N3 =:= 'biker3@127.0.0.1'],
	    {IndexB3, NodeB3} = hd(VnodesB3),
	    {_, StateB3} = riak_core_vnode_master:sync_spawn_command({IndexB3,NodeB3}, get_state, biker_vnode_master),
	    ListB3 = transform_record_to_list(StateB3),
	    ListB3Updated = [{R, C} || {R, C, _E, _P} <- ListB3],

	    VnodesB4 = [{I4, N4} || {I4, N4} <- Members, N4 =:= 'biker4@127.0.0.1'],
	    {IndexB4, NodeB4} = hd(VnodesB4),
	    {_, StateB4} = riak_core_vnode_master:sync_spawn_command({IndexB4,NodeB4}, get_state, biker_vnode_master),
	    ListB4 = transform_record_to_list(StateB4),
	    ListB4Updated = [{R, C} || {R, C, _E, _P} <- ListB4],

	    VnodesB5 = [{I5, N5} || {I5, N5} <- Members, N5 =:= 'biker5@127.0.0.1'],
	    {IndexB5, NodeB5} = hd(VnodesB5),
	    {_, StateB5} = riak_core_vnode_master:sync_spawn_command({IndexB5,NodeB5}, get_state, biker_vnode_master),
	    ListB5 = transform_record_to_list(StateB5),
	    ListB5Updated = [{R, C} || {R, C, _E, _P} <- ListB5],

		if (ListLeaderUpdated == ListB1Updated) andalso 
		   (ListLeaderUpdated == ListB2Updated) andalso
		   (ListLeaderUpdated == ListB3Updated) andalso
		   (ListLeaderUpdated == ListB4Updated) andalso
		   (ListLeaderUpdated == ListB5Updated) ->
		   			ok;
		   		true ->
		   			timer:sleep(1000),
					wait_for_ready(Leader, Cpt+1)
		end
	end.


	
% transform the record containing the global state of the system into a list of tuples
% where each tuple corresponds to a biker.
transform_record_to_list(Rec) ->
	B1State = Rec#bikers.biker1,
	[{_, RoundNumber1}] = [{K, V} || {K, V} <- B1State, K =:= 'roundNumber'],
	[{_, Crashed1}] = [{K, V} || {K, V} <- B1State, K =:= 'crashed'],
	[{_, Energy1}] = [{K, V} || {K, V} <- B1State, K =:= 'energy'],
	[{_, Position1}] = [{K, V} || {K, V} <- B1State, K =:= 'position'],
	B2State = Rec#bikers.biker2,
	[{_, RoundNumber2}] = [{K, V} || {K, V} <- B2State, K =:= 'roundNumber'],
	[{_, Crashed2}] = [{K, V} || {K, V} <- B2State, K =:= 'crashed'],
	[{_, Energy2}] = [{K, V} || {K, V} <- B2State, K =:= 'energy'],
	[{_, Position2}] = [{K, V} || {K, V} <- B2State, K =:= 'position'],
	B3State = Rec#bikers.biker3,
	[{_, RoundNumber3}] = [{K, V} || {K, V} <- B3State, K =:= 'roundNumber'],
	[{_, Crashed3}] = [{K, V} || {K, V} <- B3State, K =:= 'crashed'],
	[{_, Energy3}] = [{K, V} || {K, V} <- B3State, K =:= 'energy'],
	[{_, Position3}] = [{K, V} || {K, V} <- B3State, K =:= 'position'],
	B4State = Rec#bikers.biker4,
	[{_, RoundNumber4}] = [{K, V} || {K, V} <- B4State, K =:= 'roundNumber'],
	[{_, Crashed4}] = [{K, V} || {K, V} <- B4State, K =:= 'crashed'],
	[{_, Energy4}] = [{K, V} || {K, V} <- B4State, K =:= 'energy'],
	[{_, Position4}] = [{K, V} || {K, V} <- B4State, K =:= 'position'],
	B5State = Rec#bikers.biker5,
	[{_, RoundNumber5}] = [{K, V} || {K, V} <- B5State, K =:= 'roundNumber'],
	[{_, Crashed5}] = [{K, V} || {K, V} <- B5State, K =:= 'crashed'],
	[{_, Energy5}] = [{K, V} || {K, V} <- B5State, K =:= 'energy'],
	[{_, Position5}] = [{K, V} || {K, V} <- B5State, K =:= 'position'],

	L = [{RoundNumber1, Crashed1, Energy1, Position1},
	     {RoundNumber2, Crashed2, Energy2, Position2}, 
	     {RoundNumber3, Crashed3, Energy3, Position3}, 
	     {RoundNumber4, Crashed4, Energy4, Position4}, 
	     {RoundNumber5, Crashed5, Energy5, Position5}],

	F1 = fun (X) -> 
        case X of
            {Num, Bool, E, P} ->
	            if Bool =:= true ->
	                [];
	            true ->
	                [{Num, Bool, E, P}]
	            end
	        end
	    end,

	F2 = fun (X) -> 
        case X of
            {Num, Bool, E, P} ->
	            if E =< 0 ->
	                [];
	            true ->
	                [{Num, Bool, E, P}]
	            end
	        end
	    end,

	F3 = fun (X) -> 
        case X of
            {Num, Bool, E, P} ->
	            if P >= 100 ->
	                [];
	            true ->
	                [{Num, Bool, E, P}]
	            end
	        end
	    end,

	% only keeps correct bikers (not crashed)
    Filtered = lists:flatmap(F1, L),

    % only keeps bikers with energy > 0
    Filtered2 = lists:flatmap(F2, Filtered),

    % only keeps bikers not already arrived (position < 100)
    Filtered3 = lists:flatmap(F3, Filtered2),
    Filtered3.
 

% update the record of bikers. Each biker following another biker has its speed, position and energy updated
% Rec: record containing the global state of the system
% List: list of bikers running by themselves and followed by someone
update_record_after_follow(Rec, List) ->
    case List of
        [] ->
            Rec;
        [{Id, S, P, _F}|Rest] ->
            NewRec = propagate(Rec, Id, S, P),
            update_record_after_follow(NewRec, Rest)
    end. 


% Apply the updates (speed, position, energy) to all followers of a biker
% Rec: record containing the global state of the system
% Id: id of the following biker
% S: new speed (speed of the following)
% P: new position (position of the following)
propagate(Rec, Id, S, P) ->
    State1 = Rec#bikers.biker1,
    State2 = Rec#bikers.biker2,
    State3 = Rec#bikers.biker3,
    State4 = Rec#bikers.biker4,
    State5 = Rec#bikers.biker5,

    [{_, FollowB1}] = [{Key, Val} || {Key, Val} <- State1, Key =:= follow],
    [{_, FollowB2}] = [{Key, Val} || {Key, Val} <- State2, Key =:= follow],
    [{_, FollowB3}] = [{Key, Val} || {Key, Val} <- State3, Key =:= follow],
    [{_, FollowB4}] = [{Key, Val} || {Key, Val} <- State4, Key =:= follow],
    [{_, FollowB5}] = [{Key, Val} || {Key, Val} <- State5, Key =:= follow],

     L = [{biker1, FollowB1},
          {biker2, FollowB2},
          {biker3, FollowB3},
          {biker4, FollowB4},
          {biker5, FollowB5}],

    FilteredL = [I || {I, F} <- L, F =:= Id],
    Size = lists:flatlength(FilteredL),

    if 
        Size > 1 ->
            loop_propagate(Rec, FilteredL, S, P);
        Size =:= 1 ->
            case hd(FilteredL) of
                biker1 ->
                    [{_, EnergyB1}] = [{Key, Val} || {Key, Val} <- State1, Key =:= energy],
                    UpdatedEnergy = erlang:round(EnergyB1 - (0.06 * S * S)),
                    NewState1 = lists:sublist(State1,1) ++ [{energy, UpdatedEnergy}] ++ lists:nthtail(2,State1),
                    NewState2 = lists:sublist(NewState1,2) ++ [{position, P}] ++ lists:nthtail(3,NewState1),
                    NewState3 = lists:sublist(NewState2,3) ++ [{speed, S}] ++ lists:nthtail(4,NewState2),
                    NewRec = Rec#bikers{biker1=NewState3},
                    propagate(NewRec, biker1, S, P);
                biker2 ->
                    [{_, EnergyB2}] = [{Key, Val} || {Key, Val} <- State2, Key =:= energy],
                    UpdatedEnergy = erlang:round(EnergyB2 - (0.06 * S * S)),
                    NewState1 = lists:sublist(State2,1) ++ [{energy, UpdatedEnergy}] ++ lists:nthtail(2,State2),
                    NewState2 = lists:sublist(NewState1,2) ++ [{position, P}] ++ lists:nthtail(3,NewState1),
                    NewState3 = lists:sublist(NewState2,3) ++ [{speed, S}] ++ lists:nthtail(4,NewState2),
                    NewRec = Rec#bikers{biker2=NewState3},
                    propagate(NewRec, biker2, S, P);
                biker3 ->
                    [{_, EnergyB3}] = [{Key, Val} || {Key, Val} <- State3, Key =:= energy],
                    UpdatedEnergy = erlang:round(EnergyB3 - (0.06 * S * S)),
                    NewState1 = lists:sublist(State3,1) ++ [{energy, UpdatedEnergy}] ++ lists:nthtail(2,State3),
                    NewState2 = lists:sublist(NewState1,2) ++ [{position, P}] ++ lists:nthtail(3,NewState1),
                    NewState3 = lists:sublist(NewState2,3) ++ [{speed, S}] ++ lists:nthtail(4,NewState2),
                    NewRec = Rec#bikers{biker3=NewState3},
                    propagate(NewRec, biker3, S, P);
                biker4 ->
                    [{_, EnergyB4}] = [{Key, Val} || {Key, Val} <- State4, Key =:= energy],
                    UpdatedEnergy = erlang:round(EnergyB4 - (0.06 * S * S)),
                    NewState1 = lists:sublist(State4,1) ++ [{energy, UpdatedEnergy}] ++ lists:nthtail(2,State4),
                    NewState2 = lists:sublist(NewState1,2) ++ [{position, P}] ++ lists:nthtail(3,NewState1),
                    NewState3 = lists:sublist(NewState2,3) ++ [{speed, S}] ++ lists:nthtail(4,NewState2),
                    NewRec = Rec#bikers{biker4=NewState3},
                    propagate(NewRec, biker4, S, P);
                biker5 ->
                    [{_, EnergyB5}] = [{Key, Val} || {Key, Val} <- State5, Key =:= energy],
                    UpdatedEnergy = erlang:round(EnergyB5 - (0.06 * S * S)),
                    NewState1 = lists:sublist(State5,1) ++ [{energy, UpdatedEnergy}] ++ lists:nthtail(2,State5),
                    NewState2 = lists:sublist(NewState1,2) ++ [{position, P}] ++ lists:nthtail(3,NewState1),
                    NewState3 = lists:sublist(NewState2,3) ++ [{speed, S}] ++ lists:nthtail(4,NewState2),
                    NewRec = Rec#bikers{biker5=NewState3},
                    propagate(NewRec, biker5, S, P)
            end;
        Size =:= 0 ->
            Rec;
        true ->
            pass
    end.



% Apply the updates (speed, position, energy) to all followers of a biker
% Rec: record containing the global state of the system
% FilteredL: list of following bikers
% S: new speed (speed of the following)
% P: new position (position of the following)
loop_propagate(Rec, FilteredL, S, P) ->
    State1 = Rec#bikers.biker1,
    State2 = Rec#bikers.biker2,
    State3 = Rec#bikers.biker3,
    State4 = Rec#bikers.biker4,
    State5 = Rec#bikers.biker5,

    case FilteredL of 
        [H|T] ->
            case H of
                biker1 ->
                    [{_, EnergyB1}] = [{Key, Val} || {Key, Val} <- State1, Key =:= energy],
                    UpdatedEnergy = erlang:round(EnergyB1 - (0.06 * S * S)),
                    NewState1 = lists:sublist(State1,1) ++ [{energy, UpdatedEnergy}] ++ lists:nthtail(2,State1),
                    NewState2 = lists:sublist(NewState1,2) ++ [{position, P}] ++ lists:nthtail(3,NewState1),
                    NewState3 = lists:sublist(NewState2,3) ++ [{speed, S}] ++ lists:nthtail(4,NewState2),
                    NewRec = Rec#bikers{biker1=NewState3},
                    Res = propagate(NewRec, biker1, S, P);
                biker2 ->
                    [{_, EnergyB2}] = [{Key, Val} || {Key, Val} <- State2, Key =:= energy],
                    UpdatedEnergy = erlang:round(EnergyB2 - (0.06 * S * S)),
                    NewState1 = lists:sublist(State2,1) ++ [{energy, UpdatedEnergy}] ++ lists:nthtail(2,State2),
                    NewState2 = lists:sublist(NewState1,2) ++ [{position, P}] ++ lists:nthtail(3,NewState1),
                    NewState3 = lists:sublist(NewState2,3) ++ [{speed, S}] ++ lists:nthtail(4,NewState2),
                    NewRec = Rec#bikers{biker2=NewState3},
                    Res = propagate(NewRec, biker2, S, P);
                biker3 ->
                    [{_, EnergyB3}] = [{Key, Val} || {Key, Val} <- State3, Key =:= energy],
                    UpdatedEnergy = erlang:round(EnergyB3 - (0.06 * S * S)),
                    NewState1 = lists:sublist(State3,1) ++ [{energy, UpdatedEnergy}] ++ lists:nthtail(2,State3),
                    NewState2 = lists:sublist(NewState1,2) ++ [{position, P}] ++ lists:nthtail(3,NewState1),
                    NewState3 = lists:sublist(NewState2,3) ++ [{speed, S}] ++ lists:nthtail(4,NewState2),
                    NewRec = Rec#bikers{biker3=NewState3},
                    Res = propagate(NewRec, biker3, S, P);
                biker4 ->
                    [{_, EnergyB4}] = [{Key, Val} || {Key, Val} <- State4, Key =:= energy],
                    UpdatedEnergy = erlang:round(EnergyB4 - (0.06 * S * S)),
                    NewState1 = lists:sublist(State4,1) ++ [{energy, UpdatedEnergy}] ++ lists:nthtail(2,State4),
                    NewState2 = lists:sublist(NewState1,2) ++ [{position, P}] ++ lists:nthtail(3,NewState1),
                    NewState3 = lists:sublist(NewState2,3) ++ [{speed, S}] ++ lists:nthtail(4,NewState2),
                    NewRec = Rec#bikers{biker4=NewState3},
                    Res = propagate(NewRec, biker4, S, P);
                biker5 ->
                    [{_, EnergyB5}] = [{Key, Val} || {Key, Val} <- State5, Key =:= energy],
                    UpdatedEnergy = erlang:round(EnergyB5 - (0.06 * S * S)),
                    NewState1 = lists:sublist(State5,1) ++ [{energy, UpdatedEnergy}] ++ lists:nthtail(2,State5),
                    NewState2 = lists:sublist(NewState1,2) ++ [{position, P}] ++ lists:nthtail(3,NewState1),
                    NewState3 = lists:sublist(NewState2,3) ++ [{speed, S}] ++ lists:nthtail(4,NewState2),
                    NewRec = Rec#bikers{biker5=NewState3},
                    Res = propagate(NewRec, biker5, S, P)
            end,
            loop_propagate(Res, T, S, P);
        [] ->
            Rec
    end.


% get useful information about bikers running by themselves and followed by someone
% Rec: record containing the global state of the system.
get_bikers_running_by_themselves_info(Rec) ->
    State1 = Rec#bikers.biker1,
    State2 = Rec#bikers.biker2,
    State3 = Rec#bikers.biker3,
    State4 = Rec#bikers.biker4,
    State5 = Rec#bikers.biker5,

    [{_, FollowB1}] = [{Key, Val} || {Key, Val} <- State1, Key =:= follow],
    [{_, SpeedB1}] = [{Key, Val} || {Key, Val} <- State1, Key =:= speed],
    [{_, PositionB1}] = [{Key, Val} || {Key, Val} <- State1, Key =:= position],

    [{_, FollowB2}] = [{Key, Val} || {Key, Val} <- State2, Key =:= follow],
    [{_, SpeedB2}] = [{Key, Val} || {Key, Val} <- State2, Key =:= speed],
    [{_, PositionB2}] = [{Key, Val} || {Key, Val} <- State2, Key =:= position],

    [{_, FollowB3}] = [{Key, Val} || {Key, Val} <- State3, Key =:= follow],
    [{_, SpeedB3}] = [{Key, Val} || {Key, Val} <- State3, Key =:= speed],
    [{_, PositionB3}] = [{Key, Val} || {Key, Val} <- State3, Key =:= position],

    [{_, FollowB4}] = [{Key, Val} || {Key, Val} <- State4, Key =:= follow],
    [{_, SpeedB4}] = [{Key, Val} || {Key, Val} <- State4, Key =:= speed],
    [{_, PositionB4}] = [{Key, Val} || {Key, Val} <- State4, Key =:= position],

    [{_, FollowB5}] = [{Key, Val} || {Key, Val} <- State5, Key =:= follow],
    [{_, SpeedB5}] = [{Key, Val} || {Key, Val} <- State5, Key =:= speed],
    [{_, PositionB5}] = [{Key, Val} || {Key, Val} <- State5, Key =:= position],

    L = [{biker1, SpeedB1, PositionB1, FollowB1},
         {biker2, SpeedB2, PositionB2, FollowB2},
         {biker3, SpeedB3, PositionB3, FollowB3},
         {biker4, SpeedB4, PositionB4, FollowB4},
         {biker5, SpeedB5, PositionB5, FollowB5}],

    % get the list of bikers followed
    ListFollow = [F || {_Id, _S, _P, F} <- L, F =/= none],
    if ListFollow =:= [] ->
            ListByThemselves = [];
        true ->
            ListByThemselves = [{Id, S, P, F} || {Id, S, P, F} <- L, F =:= none andalso (present_in_list(Id, ListFollow) =:= true)]
    end,
    ListByThemselves.

% Check if an element is present in the list
present_in_list(Elem, [Head|Tail]) ->
    if Head =:= Elem ->
            true;
        true ->
             case Tail of 
                [] ->
                    false;
                [H|T] ->
                    present_in_list(Elem, [H|T])
            end
    end.


% Display the position of each biker in a decreasing order
% Rec: record containing the state of each biker
display_bikers(Rec) ->

    State1 = Rec#bikers.biker1,
    [{_, B1Position}] = [{Key, Val} || {Key, Val} <- State1, Key =:= position],
    [{_, B1Follow}] = [{Key, Val} || {Key, Val} <- State1, Key =:= follow],
    [{_, B1Crashed}] = [{Key, Val} || {Key, Val} <- State1, Key =:= crashed],

    State2 = Rec#bikers.biker2,
    [{_, B2Position}] = [{Key, Val} || {Key, Val} <- State2, Key =:= position],
    [{_, B2Follow}] = [{Key, Val} || {Key, Val} <- State2, Key =:= follow],
    [{_, B2Crashed}] = [{Key, Val} || {Key, Val} <- State2, Key =:= crashed],

    State3 = Rec#bikers.biker3,
    [{_, B3Position}] = [{Key, Val} || {Key, Val} <- State3, Key =:= position],
    [{_, B3Follow}] = [{Key, Val} || {Key, Val} <- State3, Key =:= follow],
    [{_, B3Crashed}] = [{Key, Val} || {Key, Val} <- State3, Key =:= crashed],

    State4 = Rec#bikers.biker4,
    [{_, B4Position}] = [{Key, Val} || {Key, Val} <- State4, Key =:= position],
    [{_, B4Follow}] = [{Key, Val} || {Key, Val} <- State4, Key =:= follow],
    [{_, B4Crashed}] = [{Key, Val} || {Key, Val} <- State4, Key =:= crashed],

    State5 = Rec#bikers.biker5,
    [{_, B5Position}] = [{Key, Val} || {Key, Val} <- State5, Key =:= position],
    [{_, B5Follow}] = [{Key, Val} || {Key, Val} <- State5, Key =:= follow],
    [{_, B5Crashed}] = [{Key, Val} || {Key, Val} <- State5, Key =:= crashed],

    List = [{biker1, B1Position, B1Follow, B1Crashed},
            {biker2, B2Position, B2Follow, B2Crashed},
            {biker3, B3Position, B3Follow, B3Crashed},
            {biker4, B4Position, B4Follow, B4Crashed},
            {biker5, B5Position, B5Follow, B5Crashed}],

    % remove crashed bikers
    NoCrash = [{Id, P, F, C} || {Id, P, F, C} <- List, C =/= true],

    % Sort bikers by decreasing position
    FSort = fun({_Id1,P1, _F1, _C1}, {_Id2, P2, _F2, _C2}) -> P1 >= P2 end,
    Sorted = lists:sort(FSort, NoCrash),

    Edited = [{{Id, F}, P, F, C} || {Id, P, F, C} <- Sorted],

    Edited2 = [{{Id, F}, P} || {{Id, F}, P, F, _C} <- Edited],

    F1 = fun (X) -> 
    case X of
        {{B1, B2}, P} ->
            if B2 =:= none ->
                [{B1, P}];
            true ->
                [{{B1, B2}, P}]
            end
        end
    end,

    Filtered = lists:flatmap(F1, Edited2),

    io:format("~nState of the race (max -> min distance crossed): ~n~n"),

    {_, LastDist} = hd(Filtered),

    custom_display(Filtered, LastDist, 1),

    case node() of 
        'biker1@127.0.0.1' ->
            State = Rec#bikers.biker1,
            [{_, B1Energy}] = [{Key, Val} || {Key, Val} <- State, Key =:= energy],
            io:format("Energy : ~w~n", [B1Energy]),
            [{_, B1Position}] = [{Key, Val} || {Key, Val} <- State, Key =:= position],
            io:format("Position : ~w~n~n", [B1Position]);
        'biker2@127.0.0.1' ->
            State = Rec#bikers.biker2,
            [{_, B2Energy}] = [{Key, Val} || {Key, Val} <- State, Key =:= energy],
            io:format("Energy : ~w~n", [B2Energy]),
            [{_, B2Position}] = [{Key, Val} || {Key, Val} <- State, Key =:= position],
            io:format("Position : ~w~n~n", [B2Position]);
        'biker3@127.0.0.1' ->
            State = Rec#bikers.biker3,
            [{_, B3Energy}] = [{Key, Val} || {Key, Val} <- State, Key =:= energy],
            io:format("Energy : ~w~n", [B3Energy]),
            [{_, B3Position}] = [{Key, Val} || {Key, Val} <- State, Key =:= position],
            io:format("Position : ~w~n~n", [B3Position]);
        'biker4@127.0.0.1' ->
            State = Rec#bikers.biker4,
            [{_, B4Energy}] = [{Key, Val} || {Key, Val} <- State, Key =:= energy],
            io:format("Energy : ~w~n", [B4Energy]),
            [{_, B4Position}] = [{Key, Val} || {Key, Val} <- State, Key =:= position],
            io:format("Position : ~w~n~n", [B4Position]);
        'biker5@127.0.0.1' ->
            State = Rec#bikers.biker5,
            [{_, B5Energy}] = [{Key, Val} || {Key, Val} <- State, Key =:= energy],
            io:format("Energy : ~w~n", [B5Energy]),
            [{_, B5Position}] = [{Key, Val} || {Key, Val} <- State, Key =:= position],
            io:format("Position : ~w~n~n", [B5Position])
    end.


custom_display(List, LastDist, SpaceNumber) ->
    case List of 
        [H|T] -> 
            case H of 
                {{B1, B2}, Dist} ->
                    if Dist =:= LastDist ->
                            case SpaceNumber of 
                                1 ->
                                    io:format("~1c{~w, ~w}~n", [32, B1, B2]);
                                19 ->
                                    io:format("~18c{~w, ~w}~n", [32, B1, B2]);
                                37 ->
                                    io:format("~36c{~w, ~w}~n", [32, B1, B2]);
                                55 ->
                                    io:format("~54c{~w, ~w}~n", [32, B1, B2]);
                                73 ->
                                    io:format("~72c{~w, ~w}~n", [32, B1, B2])
                            end,
                            custom_display(T, LastDist, SpaceNumber);
                        true ->
                            case SpaceNumber of 
                                1 ->
                                    io:format("~18c{~w, ~w}~n", [32, B1, B2]);
                                19 ->
                                    io:format("~36c{~w, ~w}~n", [32, B1, B2]);
                                37 ->
                                    io:format("~54c{~w, ~w}~n", [32, B1, B2]);
                                55 ->
                                    io:format("~72c{~w, ~w}~n", [32, B1, B2]);
                                73 ->
                                    io:format("~90c{~w, ~w}~n", [32, B1, B2])
                            end,
                            custom_display(T, Dist, 18+SpaceNumber)
                    end;
                {B1, Dist} -> 
                    if Dist =:= LastDist ->
                            case SpaceNumber of 
                                1 ->
                                    io:format("~1c~w~n", [32, B1]);
                                19 ->
                                    io:format("~18c~w~n", [32, B1]);
                                37 ->
                                    io:format("~36c~w~n", [32, B1]);
                                55 ->
                                    io:format("~54c~w~n", [32, B1]);
                                73 ->
                                    io:format("~72c~w~n", [32, B1])
                            end,
                            custom_display(T, LastDist, SpaceNumber);
                        true ->
                            case SpaceNumber of 
                                1 ->
                                    io:format("~18c~w~n", [32, B1]);
                                19 ->
                                    io:format("~36c~w~n", [32, B1]);
                                37 ->
                                    io:format("~54c~w~n", [32, B1]);
                                55 ->
                                    io:format("~72c~w~n", [32, B1]);
                                73 ->
                                    io:format("~90c~w~n", [32, B1])
                            end,
                            custom_display(T, Dist, 18+SpaceNumber)
                    end
            end;
        [] ->
            io:format("~n")
    end.    


% Check if a biker has won the race
% a biker is a winner when he has covered a distance of 100 or higher
winner(Rec)->
	State1 = Rec#bikers.biker1,
    State2 = Rec#bikers.biker2,
    State3 = Rec#bikers.biker3,
    State4 = Rec#bikers.biker4,
    State5 = Rec#bikers.biker5,

    [{_, FollowB1}] = [{Key, Val} || {Key, Val} <- State1, Key =:= follow],
    [{_, FollowB2}] = [{Key, Val} || {Key, Val} <- State2, Key =:= follow],
    [{_, FollowB3}] = [{Key, Val} || {Key, Val} <- State3, Key =:= follow],
    [{_, FollowB4}] = [{Key, Val} || {Key, Val} <- State4, Key =:= follow],
    [{_, FollowB5}] = [{Key, Val} || {Key, Val} <- State5, Key =:= follow],

    [{_, PositionB1}] = [{Key, Val} || {Key, Val} <- State1, Key =:= position],
    [{_, PositionB2}] = [{Key, Val} || {Key, Val} <- State2, Key =:= position],
    [{_, PositionB3}] = [{Key, Val} || {Key, Val} <- State3, Key =:= position],
    [{_, PositionB4}] = [{Key, Val} || {Key, Val} <- State4, Key =:= position],
    [{_, PositionB5}] = [{Key, Val} || {Key, Val} <- State5, Key =:= position],

    L = [{biker1, FollowB1, PositionB1},
         {biker2, FollowB2, PositionB2},
         {biker3, FollowB3, PositionB3},
         {biker4, FollowB4, PositionB4},
         {biker5, FollowB5, PositionB5}],

    Filtered = [{Id, P} || {Id, F, P} <- L, F =:= none, P >= 100],

    case Filtered of 
    	[] -> 
    		false;
    	_ ->
    		% Sort bikers by decreasing position
		    Sort = fun({_Id1, P1}, {_Id2, P2}) -> P1 >= P2 end,
		    Sorted = lists:sort(Sort, Filtered),
		    {Winner, _} = hd(Sorted),
		    io:format("~n~nWINNER OF THE RACE: ~w~n~n", [Winner]),
		    timer:sleep(infinity)
    end.




    












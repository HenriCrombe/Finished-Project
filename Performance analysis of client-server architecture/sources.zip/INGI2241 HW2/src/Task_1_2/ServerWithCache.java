package Task_1_2;
import java.net.*;
import java.util.HashMap;
import java.util.Map;
import java.io.*;


public class ServerWithCache {
	
	/**
	 * This class Server is used to generate results for measurements #2
	 * 
	 * In the context of measurements #2, the server must process one request at a time. 
	 * Therefore, only one client is served at a time. 
	 * When a client connects to the server, a socket and the input/output streams are created. 
	 * Then, the request is computed and sent back to the client.
	 * If a client connects when another client is being processed, it has to wait in the ServerSocket queue.
	 */

	public static void main(String[] args) {
		try {
			System.out.println("Server started for measurements #2");
			
			// Create ServerSocket on port 4444
			int port = 4444;
			ServerSocket ss = new ServerSocket(port,10000);
			
			// Initialize the cache
			SimpleCache cache = new SimpleCache(50);
			
			while(true){
				// Wait for a client to connect on port 4444. 
				// Upon arrival of a client, create a socket
				Socket client_socket = ss.accept();
				// Create Input/Output streams
				ObjectInputStream client_input = new ObjectInputStream(client_socket.getInputStream());
				ObjectOutputStream client_output = new ObjectOutputStream(client_socket.getOutputStream());
				
				// Read the request
				Message m = (Message) client_input.readObject();

				if((m.result=cache.get(m.exponent)) != null){
					System.out.println("Cache hit !");
					// if the result is already in cache, send the answer directly
					m.execution_time = 0;
					client_output.writeObject(m);
				} else{
					// if the result has to be computed (not in cache)
					// Compute M^e and computation time
					long start = System.nanoTime();
					m.result = m.matrix.exponent(m.exponent);
					long exec_time = System.nanoTime() - start;
					
					m.execution_time = exec_time / 1000000 ; // transform in ms
		
					// Send the result back to the client
					client_output.writeObject(m);
					
					// Update cache
					cache.put(m.exponent, m.result);		
				}
				// close socket and streams
				client_input.close();
				client_output.close();
				client_socket.close();	
			}
			
		} catch(Exception e){System.out.println(e);}
	}	
}

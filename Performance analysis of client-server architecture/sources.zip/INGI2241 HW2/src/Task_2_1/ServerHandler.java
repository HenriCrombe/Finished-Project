package Task_2_1;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;


public class ServerHandler  implements Runnable {
	private final Socket client_socket;

	ServerHandler(Socket socket) { this.client_socket = socket; }


	public void run() {
		try {
			
			// Create streams for the current socket
			ObjectInputStream client_input = new ObjectInputStream(client_socket.getInputStream());
			ObjectOutputStream client_output = new ObjectOutputStream(client_socket.getOutputStream());
			
			// Retrieve client request
			Message m = (Message) client_input.readObject();

			// Compute the answer
			long start = System.nanoTime();
			m.result = m.matrix.exponent(m.exponent);
			long exec_time = System.nanoTime() - start;
			m.execution_time = exec_time / 1000000 ; // in ms

			// Send the result back to the client
			client_output.writeObject(m);

			// close socket & streams.
			client_input.close();
			client_output.close();
			client_socket.close();


		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}	   	   
	}
}

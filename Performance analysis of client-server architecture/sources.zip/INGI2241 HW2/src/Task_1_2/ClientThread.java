package Task_1_2;

import java.io.BufferedWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.util.Random;
import java.util.concurrent.atomic.AtomicInteger;


public class ClientThread extends Thread {
	
	/**
	 * The ClientThread class represents a client that connects to the server and sends an individual request.
	 * 
	 * In the context of our experimentation, a client generates a request
	 * with a matrix of size 50x50 and with a random exponent contained between [500;1000].
	 * With an exponent varying between [500;1000], the expected execution time (on the server side)
	 * is contained between [200ms;600ms]. 
	 */
	
	// store parameter for later use
	int id; // id of the client
	BufferedWriter log;
	AtomicInteger mean_response_time;
	AtomicInteger mean_exec_time;
	
	public ClientThread(int i, AtomicInteger mean_response_time,AtomicInteger mean_exec_time, BufferedWriter log){
		this.id = i;
		this.log = log;
		this.mean_response_time = mean_response_time;
		this.mean_exec_time = mean_exec_time;
	}
	
	public void run() {
		try {
						
			// Generate Request with random difficulties:
			// p (exponent) varies between p_min and p_max 
			// This gives --> [min_exc_time;max_exc_time] -> [200ms;600ms];
			Random rand = new Random();
			int p_min = 500;
			int p_max = 1000;
			int p = rand.nextInt(p_max-p_min) + p_min;
			
			// Initialiaze an matrix 50x50 with random values
			Matrix m = new  Matrix(50,50);
			
			// Initialiaze the request
			Message message = new Message(id, m, p);
			message.sending_time = System.nanoTime();
			// Create the socket and connect to the distant server
			Socket s = new Socket();
			
			s.connect(new InetSocketAddress("stuycklvpn.noip.me",4444),999999999); // set connect timeout to max.
			
			// Create input and output streams
			ObjectOutputStream clientOut= new ObjectOutputStream(s.getOutputStream());
			ObjectInputStream clientIn= new ObjectInputStream(s.getInputStream());

			
		    // Blocking call to writeObject. 
	        // The message is sent when the server open its input stream.
			clientOut.writeObject(message);
			
			// Blocking call to readObject
			// The client waits until the server responds to the current request (i.e. Message).
			Message r = (Message) clientIn.readObject(); // blocking method

			// Compute the response time for the current request.
			r.arrival_time = System.nanoTime();
			r.response_time = (r.arrival_time - r.sending_time)/ 1000000; // in milliseconds
			
			// Compute the time spent on the network
			r.time_on_network = r.response_time - r.execution_time;
			
			// Update mean values
			mean_response_time.set((int) (mean_response_time.get()+r.response_time));
			mean_exec_time.set((int) (mean_exec_time.get()+r.execution_time));
			
			// Log the resulting message into the log file
			Client.log_message(log, r);
			
			// Close socket and streams.
			clientIn.close();
			clientOut.close();
			s.close();
			
		} catch (IOException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}
}
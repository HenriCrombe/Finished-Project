-module(biker_vnode).
-behaviour(riak_core_vnode).
-include("biker.hrl").

-export([start_vnode/1,
         init/1,
         terminate/2,
         handle_command/3,
         is_empty/1,
         delete/1,
         handle_handoff_command/3,
         handoff_starting/2,
         handoff_cancelled/1,
         handoff_finished/2,
         handle_handoff_data/2,
         encode_handoff_item/2,
         handle_coverage/4,
         handle_exit/3]).

-record(state, {partition, s}).
-record(bikers, {biker1, biker2, biker3, biker4, biker5}).

%% API
start_vnode(I) ->
    riak_core_vnode_master:get_vnode_pid(I, ?MODULE).

init([Partition]) ->
	% initialize the vnode state
	S = [{dist_end, 100}, 
         {energy, 112}, 
         {position, 0}, 
         {speed, 0},  
         {follow, none},  
         {crashed, false},
         {roundNumber, 1}],
    Rec = #bikers{biker1 = S, biker2 = S, biker3 = S, biker4= S, biker5 = S},
    {ok, #state{partition=Partition, s=Rec}}.

%% Sample command: respond to a ping
handle_command(ping, _Sender, State) ->
    {reply, {pong, State#state.partition}, State};

% return the state of the vnode
handle_command(get_state, _Sender, State) ->
    N = node(),
    {reply, {N, State#state.s}, State};


% update the state of the vnode according to the broadcasted speed 
% S: broadcasted speed.
% Node: id of the node sending the commande.
handle_command({send_speed, S, Node}, _Sender, #state{s=CurrentState}=State) ->
    case Node of 
        'biker1@127.0.0.1' ->
            B1State = CurrentState#bikers.biker1,
            NewState = update_speed(B1State, S),
            NewState2 = update_position(NewState, S),
            NewState3 = update_energy(NewState2, S),
            NewState4 = update_roundNumber(NewState3, 1),
            NewState5 = update_follow(NewState4, none),
            NewRec = CurrentState#bikers{biker1 = NewState5},
            {reply, {node(), NewRec}, State#state{s=NewRec}};
        'biker2@127.0.0.1' ->
            B2State = CurrentState#bikers.biker2,
            NewState = update_speed(B2State, S),
            NewState2 = update_position(NewState, S),
            NewState3 = update_energy(NewState2, S),
            NewState4 = update_roundNumber(NewState3, 1),
            NewState5 = update_follow(NewState4, none),
            NewRec = CurrentState#bikers{biker2 = NewState5},
            {reply, {node(), NewRec}, State#state{s=NewRec}};
        'biker3@127.0.0.1' ->
            B3State = CurrentState#bikers.biker3,
            NewState = update_speed(B3State, S),
            NewState2 = update_position(NewState, S),
            NewState3 = update_energy(NewState2, S),
            NewState4 = update_roundNumber(NewState3, 1),
            NewState5 = update_follow(NewState4, none),
            NewRec = CurrentState#bikers{biker3 = NewState5},
            {reply, {node(), NewRec}, State#state{s=NewRec}};
        'biker4@127.0.0.1' ->
            B4State = CurrentState#bikers.biker4,
            NewState = update_speed(B4State, S),
            NewState2 = update_position(NewState, S),
            NewState3 = update_energy(NewState2, S),
            NewState4 = update_roundNumber(NewState3, 1),
            NewState5 = update_follow(NewState4, none),
            NewRec = CurrentState#bikers{biker4 = NewState5},
            {reply, {node(), NewRec}, State#state{s=NewRec}};
        'biker5@127.0.0.1' ->
            B5State = CurrentState#bikers.biker5,
            NewState = update_speed(B5State, S),
            NewState2 = update_position(NewState, S),
            NewState3 = update_energy(NewState2, S),
            NewState4 = update_roundNumber(NewState3, 1),
            NewState5 = update_follow(NewState4, none),
            NewRec = CurrentState#bikers{biker5 = NewState5},
            {reply, {node(), NewRec}, State#state{s=NewRec}}
    end;

% update the state of the vnode (after the boost)
% Node: id of the node sending the commande.
handle_command({send_boost, Node}, _Sender, #state{s=CurrentState}=State) ->
    case Node of
        'biker1@127.0.0.1' ->
            B1State = CurrentState#bikers.biker1,
            NewState = update_speed_boost(B1State),
            [{_, S}] = [{Key, Val} || {Key, Val} <- NewState, Key =:= speed],
            NewState2 = update_position(NewState, S),
            NewState3 = update_energy_boost(NewState2),
            NewState4 = update_roundNumber(NewState3, 1),
            NewState5 = update_follow(NewState4, none),
            NewRec = CurrentState#bikers{biker1 = NewState5},
            {reply, {node(), NewRec}, State#state{s=NewRec}};
        'biker2@127.0.0.1' ->
            B2State = CurrentState#bikers.biker2,
            NewState = update_speed_boost(B2State),
            [{_, S}] = [{Key, Val} || {Key, Val} <- NewState, Key =:= speed],
            NewState2 = update_position(NewState, S),
            NewState3 = update_energy_boost(NewState2),
            NewState4 = update_roundNumber(NewState3, 1),
            NewState5 = update_follow(NewState4, none),
            NewRec = CurrentState#bikers{biker2 = NewState5},
            {reply, {node(), NewRec}, State#state{s=NewRec}};
        'biker3@127.0.0.1' ->
            B3State = CurrentState#bikers.biker3,
            NewState = update_speed_boost(B3State),
            [{_, S}] = [{Key, Val} || {Key, Val} <- NewState, Key =:= speed],
            NewState2 = update_position(NewState, S),
            NewState3 = update_energy_boost(NewState2),
            NewState4 = update_roundNumber(NewState3, 1),
            NewState5 = update_follow(NewState4, none),
            NewRec = CurrentState#bikers{biker3 = NewState5},
            {reply, {node(), NewRec}, State#state{s=NewRec}};
        'biker4@127.0.0.1' ->
            B4State = CurrentState#bikers.biker4,
            NewState = update_speed_boost(B4State),
            [{_, S}] = [{Key, Val} || {Key, Val} <- NewState, Key =:= speed],
            NewState2 = update_position(NewState, S),
            NewState3 = update_energy_boost(NewState2),
            NewState4 = update_roundNumber(NewState3, 1),
            NewState5 = update_follow(NewState4, none),
            NewRec = CurrentState#bikers{biker4 = NewState5},
            {reply, {node(), NewRec}, State#state{s=NewRec}};
        'biker5@127.0.0.1' ->
            B5State = CurrentState#bikers.biker5,
            NewState = update_speed_boost(B5State),
            [{_, S}] = [{Key, Val} || {Key, Val} <- NewState, Key =:= speed],
            NewState2 = update_position(NewState, S),
            NewState3 = update_energy_boost(NewState2),
            NewState4 = update_roundNumber(NewState3, 1),
            NewState5 = update_follow(NewState4, none),
            NewRec = CurrentState#bikers{biker5 = NewState5},
            {reply, {node(), NewRec}, State#state{s=NewRec}}
    end; 


% update the state of the vnode (assign the follow field with BikerId and set handleFollow to true)
% BikerId: Id of the followed biker
% Node: id of the node sending the commande.
handle_command({send_follow, BikerId, Node}, _Sender, #state{s=CurrentState}=State) ->
    case Node of 
        'biker1@127.0.0.1' ->
            B1State = CurrentState#bikers.biker1,
            NewState = update_follow(B1State, BikerId),
            %NewState2 = update_handleFollow(NewState, true),
            NewState2 = update_roundNumber(NewState, 1),
            NewRec = CurrentState#bikers{biker1 = NewState2},
            {reply, {node(), NewRec}, State#state{s=NewRec}};
        'biker2@127.0.0.1' ->
            B2State = CurrentState#bikers.biker2,
            NewState = update_follow(B2State, BikerId),
            %NewState2 = update_handleFollow(NewState, true),
            NewState2 = update_roundNumber(NewState, 1),
            NewRec = CurrentState#bikers{biker2 = NewState2},
            {reply, {node(), NewRec}, State#state{s=NewRec}};
        'biker3@127.0.0.1' ->
            B3State = CurrentState#bikers.biker3,
            NewState = update_follow(B3State, BikerId),
            %NewState2 = update_handleFollow(NewState, true),
            NewState2 = update_roundNumber(NewState, 1),
            NewRec = CurrentState#bikers{biker3 = NewState2},
            {reply, {node(), NewRec}, State#state{s=NewRec}};
        'biker4@127.0.0.1' ->
            B4State = CurrentState#bikers.biker4,
            NewState = update_follow(B4State, BikerId),
            %NewState2 = update_handleFollow(NewState, true),
            NewState2 = update_roundNumber(NewState, 1),
            NewRec = CurrentState#bikers{biker4 = NewState2},
            {reply, {node(), NewRec}, State#state{s=NewRec}};
        'biker5@127.0.0.1' ->
            B5State = CurrentState#bikers.biker5,
            NewState = update_follow(B5State, BikerId),
            %NewState2 = update_handleFollow(NewState, true),
            NewState2 = update_roundNumber(NewState, 1),
            NewRec = CurrentState#bikers{biker5 = NewState2},
            {reply, {node(), NewRec}, State#state{s=NewRec}}
    end;

handle_command({broadcast_new_state, NewState}, _Sender, State) ->
    {reply, {node(), ok}, State#state{s=NewState}};

handle_command({heartbeat, Start}, _Sender, State) ->
    {reply, {node(), Start}, State};


handle_command(Message, _Sender, State) ->
    ?PRINT({unhandled_command, Message}),
    {noreply, State}.

handle_handoff_command(_Message, _Sender, State) ->
    {noreply, State}.

handoff_starting(_TargetNode, State) ->
    {true, State}.

handoff_cancelled(State) ->
    {ok, State}.

handoff_finished(_TargetNode, State) ->
    {ok, State}.

handle_handoff_data(_Data, State) ->
    {reply, ok, State}.

encode_handoff_item(_ObjectName, _ObjectValue) ->
    <<>>.

is_empty(State) ->
    {true, State}.

delete(State) ->
    {ok, State}.

handle_coverage(_Req, _KeySpaces, _Sender, State) ->
    {stop, not_implemented, State}.

handle_exit(_Pid, _Reason, State) ->
    {noreply, State}.

terminate(_Reason, _State) ->
    ok.

% update the state of the vnode (biking by myself)
% State: current state
% Input: speed choosen by the user
update_energy(State, Input) ->
    CurrentField = [{Key, Val} || {Key, Val} <- State, Key =:= energy],
    UpdatedField = case CurrentField of
                        [{_K, _V}] ->
                            {_K, erlang:round(_V - (0.12 * Input * Input))}
                    end,
    NewState = lists:sublist(State,1) ++ [UpdatedField] ++ lists:nthtail(2,State),
    NewState.

% update the state of the vnode (after boost)
% State: current state
% Input: speed choosen by the user
update_energy_boost(State) ->
    CurrentField = [{Key, Val} || {Key, Val} <- State, Key =:= energy],
    UpdatedField = case CurrentField of
                        [{_K, _V}] ->
                            {_K, 0}
                    end,
    NewState = lists:sublist(State,1) ++ [UpdatedField] ++ lists:nthtail(2,State),
    NewState.

% update the state of the vnode 
% State: current state
% Input: speed of the followed biker
% update_energy_after_follow(State, Input) ->
%     CurrentField = [{Key, Val} || {Key, Val} <- State, Key =:= energy],
%     UpdatedField = case CurrentField of
%                         [{_K, _V}] ->
%                             {_K, erlang:round(_V - (0.06 * Input * Input))}
%                     end,
%     NewState = lists:sublist(State,1) ++ [UpdatedField] ++ lists:nthtail(2,State),
%     NewState.

% update the state of the vnode
% State: current state
% Input: speed choosen by the user
update_position(State, Input) ->
    CurrentField = [{Key, Val} || {Key, Val} <- State, Key =:= position],
    UpdatedField = case CurrentField of
                        [{_K, _V}] ->
                            {_K, _V + Input}
                    end,
    NewState = lists:sublist(State,2) ++ [UpdatedField] ++ lists:nthtail(3,State),
    NewState.

% update the state of the vnode
% State: current state
% Input: new position (same position as followed biker)
% update_position_after_follow(State, Input) ->
%     CurrentField = [{Key, Val} || {Key, Val} <- State, Key =:= position],
%     UpdatedField = case CurrentField of
%                         [{_K, _V}] ->
%                             {_K, Input}
%                     end,
%     NewState = lists:sublist(State,2) ++ [UpdatedField] ++ lists:nthtail(3,State),
%     NewState.

% update the state of the vnode
% State: current state
% Input: new value for the speed
update_speed(State, Input) ->
    CurrentField = [{Key, Val} || {Key, Val} <- State, Key =:= speed],
    UpdatedField = case CurrentField of
                        [{_K, _V}] ->
                            {_K, Input}
                    end,
    NewState = lists:sublist(State,3) ++ [UpdatedField] ++ lists:nthtail(4,State),
    NewState.

% update the state of the vnode
% State: current state
% Input: new value for the speed
update_speed_boost(State) ->
    CurrentField = [{Key, Val} || {Key, Val} <- State, Key =:= speed],
    UpdatedField = case CurrentField of
                        [{_K, _V}] ->
                            % get remaining energy
                            [{_, E}] =  [{Key, Val} || {Key, Val} <- State, Key =:= energy],
                            {_K, erlang:round(3.87 * math:sqrt(E))}
                    end,
    NewState = lists:sublist(State,3) ++ [UpdatedField] ++ lists:nthtail(4,State),
    NewState.

% update the state of the vnode
% State: current state
% BikerId: id of the followed biker 
update_follow(State, BikerId) ->
    CurrentField = [{Key, Val} || {Key, Val} <- State, Key =:= follow],
    UpdatedField = case CurrentField of
                        [{_K, _V}] ->
                            {_K, BikerId}
                    end,
    NewState = lists:sublist(State,4) ++ [UpdatedField] ++ lists:nthtail(5,State),
    NewState.

% % update the state of the vnode (assign the value of Input to handleFollow's field)
% % State: current state
% % Input : true/false
% update_handleFollow(State, Input) ->
%     CurrentField = [{Key, Val} || {Key, Val} <- State, Key =:= handleFollow],
%     UpdatedField = case CurrentField of
%                         [{_K, _V}] ->
%                             {_K, Input}
%                     end,
%     NewState = lists:sublist(State,5) ++ [UpdatedField] ++ lists:nthtail(6,State),
%     NewState.

% update the state of the vnode (increment the round number)
% State: current state
% Input : 1
update_roundNumber(State, Input) ->
    CurrentField = [{Key, Val} || {Key, Val} <- State, Key =:= roundNumber],
    UpdatedField = case CurrentField of
                        [{_K, V}] ->
                            if (V + Input) > 5 ->
                                    {_K, 1};
                                true ->
                                    {_K, (V + Input)}
                            end
                    end,
    NewState = lists:sublist(State,6) ++ [UpdatedField],
    NewState.



% % update the state of the vnodes corresponding to a biker following another biker
% handle_command({apply_follow_updates, Speed, Position}, _Sender, #state{s=CurrentState}=State) ->
%     NewState1 = update_speed(CurrentState, Speed),
%     NewState2 = update_position_after_follow(NewState1, Position),
%     NewState3 = update_energy_after_follow(NewState2, Speed),
%     NewState4 = update_follow(NewState3, none),
%     NewState5 = update_handleFollow(NewState4, false),
%     {reply, {node(), NewState5}, State#state{s=NewState5}};


















package Task_1_2;
import java.net.*;
import java.util.ArrayList;
import java.util.concurrent.atomic.AtomicInteger;
import java.io.*;


public class Client {

	/**
	 * This Client class acts like a load generator for measurement #2, modeling #1 and task 2.2 (multithreading)
	 * 
	 * The load generator sends random requests of varying difficulties to the server (p between [500,1000]). 
	 * It simulates the the behavior of many independent clients by sending requests with exponentially distributed inter-request times.
	 * The clients are simulated by running several threads ClientThread.
	 */
	
	public static void main(String[] args) throws UnknownHostException, IOException, ClassNotFoundException, InterruptedException {

		System.out.println("Client - Load Generator started");
		
		double coeff= 2; // Start with coeff=20 which equals to sending rate of 2 req/s
		
		// Stop when lambda reaches 40 (stop when sending rate reaches 4 req/s)
		for(;coeff<=40;){
			
			// Initialize log to store results for the given lambda
			BufferedWriter log = init_log("task_1_caching_50_p_rand_500_1000_"+coeff+"");
			System.out.println("lambda "+coeff);
			
			// Initialize mean values
			AtomicInteger mean_response_time = new AtomicInteger(0);
			AtomicInteger mean_exec_time = new AtomicInteger(0);
			
			int nmb_request = 500; // nmb of request to send for a given lambda
			
			// Create a list of threads to store the started Client (ClientThread)
			// One ClientThread represents a clients that only sends one request
			// A ClientThread stops when it has received a response from the server
			ArrayList<Thread> threads = new ArrayList<Thread>();
			
			long start_time = System.nanoTime(); // used to calculte the real sending rate
			
			for(int i=0; i<nmb_request; i++){
				
				// Wait for a random time between 0 and 10 sec
				long time_to_wait = (long) (10000*generate_expo_request_time(coeff));
				Thread.sleep(time_to_wait);   
				System.out.println("sendrequest");
				// Create a new client
				// The client will create a socket and will send only one request to the server
				// When the client receives an answer, it updates mean values and store the result into the log.
				Thread client_thread = new ClientThread(i,mean_response_time,mean_exec_time,log);
				
				// Add client thread to the client list.
				threads.add(client_thread);
				client_thread.start();	
			}
			
			// Compute real request rate
			long stop_time = System.nanoTime();
			long exec_sending_time = (stop_time - start_time)/1000000000;
			double req_rate = (double)(nmb_request) / (double)(exec_sending_time);
	
			
			// Wait for all client thread to finish
			for(Thread t : threads){
				t.join();
			}
			
			// Compute mean values
			mean_response_time.set(mean_response_time.get()/nmb_request);
			mean_exec_time.set(mean_exec_time.get()/nmb_request);
			
			// Write mean values into log file
			log.write("Finished : \n Lambda = "+coeff+"\n Req Rate (req/s) :"+req_rate+" (expected :"+coeff*0.1+")\n Mean response time = "+mean_response_time.get()+" ms \n Mean exec time : "+mean_exec_time);
			log.close();

			// Adjust the request rate by adjusting coeff a
			coeff +=1;
		}
			
        System.out.println("Client - Load generator : FINISHED");					
	} // End of main()
	
	/**
	 * This method is used to generate exponentially distributed inter-request times.
	 * High coeff means high request rate (req/s). 
	 * @param coeff
	 * @return a value between [0,1] exponentially distributed by lambda.
	 */
	public static double generate_expo_request_time(double coeff){
		double value = 0;
		double u = Math.random();
		value = Math.log((1-u))/(-coeff);
		return value;
	}
	
	public static void log_message(BufferedWriter log, Message m) throws IOException{

		log.write("Message "+m.id+" :\n");
		log.write("Matrix size : "+m.matrix.c+" | exponent : "+m.exponent+" | RTT : "+m.response_time+" ms | execution time : "+m.execution_time+" ms | Network + buffer time : "+m.time_on_network+" \n");
	}
	
	public static BufferedWriter init_log(String filename) throws IOException{
		File file = new File(filename);
		if (!file.exists()) {
			file.createNewFile();
		}
		FileWriter fw = new FileWriter(file.getAbsoluteFile());
		return new BufferedWriter(fw);
	}
	
} // end of class client

package Task_1_1;
import java.net.*;
import java.io.*;


public class Server {

	public static void main(String[] args) throws IOException, ClassNotFoundException {
		
		// Start ServerSocket on port 4444
		int port = 4444;
		ServerSocket ss = new ServerSocket(port);
		
		while(true){
			
			// Blocking call to accept()
			// A socket is created when a client connect to the server socket
			Socket pipe = ss.accept();
			
			// Create input and output streams for the newly created socket
			ObjectInputStream serverIn = new ObjectInputStream(pipe.getInputStream());
			ObjectOutputStream serverOut = new ObjectOutputStream(pipe.getOutputStream());
			
			// Read the request coming from the client
			Message request = (Message) serverIn.readObject();

			// Compute M^e and compute the execution time
			long start = System.nanoTime();
			request.result = request.matrix.exponent(request.exponent);
			long exec_time = System.nanoTime() - start;
			
			// Stores the execution time in milliseconds
			request.execution_time = exec_time/1000000;
			
			// Send the message with the computation result back to the client
			serverOut.writeObject(request);

			// Close sockets and streams
			serverIn.close();
			serverOut.close();
			pipe.close();
		}
	} // end of main
} // end of class Server

package Task_1_2;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class SimpleCache {
	int size;
	int eldest_key;
	
	Map<Integer, Matrix> cache;
	ArrayList<Integer> keys;
	
	public SimpleCache(int size){
		this.size =size;
		cache = new HashMap<Integer, Matrix>();
		keys  = new ArrayList<Integer>();;
	}
	
	public void put(int key, Matrix m){
		if(cache.size() < size && !cache.containsKey(key)){
			cache.put(key, m);
			keys.add(key);
			size++;
		}
		else if(cache.size() == size && !cache.containsKey(key)) {
			cache.remove(keys.remove(0));
			cache.put(key, m);
			keys.add(key);
		}
	}
	
	
	public Matrix get(int key){
		return cache.get(key);	
	}

}
